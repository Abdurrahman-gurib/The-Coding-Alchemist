<?php 

session_start();

if (!isset($_SESSION['username'])) {
    header("Location: index.php");
}

?>



<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
  <meta charset="utf-8">
  <!-- google fonts -->
  <link rel="icon" href="favicon (2).ico">
  <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;900&family=Ubuntu:wght@300&display=swap" rel="stylesheet">
  <link rel="preconnect" href="https://fonts.gstatic.com">
  <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@100;300;500;600&family=Open+Sans:wght@300&display=swap" rel="stylesheet">
  <link rel="preconnect" href="https://fonts.gstatic.com">
  <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@100;300;500;600&family=Open+Sans:wght@300&family=Roboto:wght@100;300;400;500;900&display=swap" rel="stylesheet">
  <!-- css stylesheet -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
  <link rel="stylesheet" href="css\welcome2.css">
  <!-- fontawesome -->
  <script src="https://kit.fontawesome.com/02c31ebc15.js" crossorigin="anonymous"></script>
  <title>Noor-Ul-Haqq</title>
  <!-- Bootstrap Scripts -->
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</head>

 <body style="background-color:grey;">
  <section class="colored-section" id="title">
    <div>
      <!-- Nav Bar -->
      <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <a class="navbar-brand navbar-title" href="#">The Coding Alchemist <i class="fas fa-user-md"></i></a>
        <a style="color:white;position:relative;left:1200px"; href="logout.php">Logout</a>
        
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav mr-auto content">
            <li class="nav-item active">
            <?php 
	print"<font color='white'>    " . $_SESSION['username'].""
  
  
	?>
  <i class='fas fa-user-alt'></i>
            </li>
            <li class="nav-item active">
              
            </li>
            <!-- <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                Dropdown
              </a> -->
            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
              <a class="dropdown-item" href="#">Action</a>
              <a class="dropdown-item" href="#">Another action</a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item" href="#">Something else here</a>
            </div>
          </ul>
          <form class="form-inline my-2 my-lg-0">
            
          </form>
        </div>
      </nav>
    </div>
    <!-- Title -->
    <div class="first_section">
      <div class="Big-heading">
        <h1 style="color:	#FFEBCD;position:relative;left:500px;bottom: 20px;">Welcome</h1>
        
        <a href="./symptom checker/index.htm" class="start-session-btn btn btn-dark btn-lg" style="margin:45px; role="button" aria-pressed="true">Telemedicine</a> 
        <a href="./FitCalc-main/index.html" class="start-session-btn btn btn-dark btn-lg" style="margin:45px;position:relative;top: 150px;right: 235px; role="button" aria-pressed="true">Fitness</a>
        <a href="http://localhost/charity/" class="start-session-btn btn btn-dark btn-lg" style="margin:45px;position:relative;top: 300px;right: 430px; role="button" aria-pressed="true">Donation</a> 
        <span class="tooltiptext"style="margin:45px;position:relative;top: 5px;right: 435px;">Feeling sick? check your symptoms and appoint a doctor easily from locations of the nearest hospitals</span>
        <p style="position:relative;top: 70px;left: 250px;">To keep the body in good health is a duty</p>
        <br>
        <p style="position:relative;top: 160px;left: 250px;">Make a change in someone's life</p>
        
      </div>
      <div class="images">
        <img class="doctor-images1" src="https://media-public.canva.com/Y_9M8/MAD0tTY_9M8/1/s.svg" alt="Doctor-image">
        <img class="doctor-images2" src="https://media-public.canva.com/TAwhg/MAD0tYTAwhg/1/s.svg" alt="Doctor-image">
        <img class="doctor-images3" src="https://media-public.canva.com/PwcmI/MAD0tYPwcmI/1/s.svg" alt="Doctor-image">
      </div>
    </div>
  </section>
  <!-- Footer -->


</body>

</html>
