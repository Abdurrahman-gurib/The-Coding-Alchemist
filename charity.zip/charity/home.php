 <!-- Header-->
 <header class="bg-dark py-5" id="main-header">
    <div class="container px-4 px-lg-5 my-5">
        <div class="text-center text-white">
        <br><br><br><br><br><br>
            <h1>Alone we can do so little; together we can do so much<h1/>
            <br>
            <h6>HELEN KELLER<h6/>
            <br><br><br><br><br><br><br><br><br><br><br><br><br><br>
            <p class="lead fw-normal text-white-50 mb-0"></p>
        </div>
    </div>
</header>
<!-- Section-->
<style>
    .book-cover{
        object-fit:contain !important;
        height:auto !important;
    }
</style>
<section class="py-5">
    <div class="container px-4 px-lg-5 mt-5">
        <?php require_once('welcome_content.html') ?>
    </div>
</section>